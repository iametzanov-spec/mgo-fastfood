const translations={
  ru:{home:'Главная',menu:'Меню',about:'О нас',reviews:'Отзывы',contacts:'Контакты',tagline:'Вкус, который хочется повторить',seeMenu:'Смотреть меню',menuTitle:'Меню',menuNote:'Оригинальное меню MGO. Фотографии ниже показаны целиком, без замены содержимого.',aboutTitle:'О нас',aboutText:'MGO — современное заведение с яркой атмосферой и большим выбором любимых блюд. Здесь можно выбрать всё от бургеров и пиццы до суши, сетов и закусок.',reviewsTitle:'Люди о нас',r1:'Очень вкусно и атмосферно. Обязательно вернусь!',r2:'Большое меню, всё выглядит аппетитно. Понравился выбор.',r3:'Понравилось обслуживание и вкус блюд. Остались хорошие впечатления.',r4:'Хорошее место, чтобы посидеть и выбрать что-нибудь вкусное.',contactsTitle:'Контакты',phoneLabel:'Телефон заведения',call:'Позвонить',gis:'Мы в 2GIS',supportEyebrow:'Техническая поддержка',supportTitle:'Техническая поддержка',supportNote:'По вопросам работы сайта',supportCall:'Связаться с техподдержкой',footerText:'Официальный сайт-визитка'},
  kz:{home:'Басты бет',menu:'Мәзір',about:'Біз туралы',reviews:'Пікірлер',contacts:'Байланыс',tagline:'Қайта-қайта жегіңіз келетін дәм',seeMenu:'Мәзірді көру',menuTitle:'Мәзір',menuNote:'MGO мәзірінің түпнұсқа беттері. Фотосуреттер толық көрсетілген, мазмұны өзгертілмеген.',aboutTitle:'Біз туралы',aboutText:'MGO — жарқын атмосферасы және сүйікті тағамдардың кең таңдауы бар заманауи орын. Мұнда бургерлерден пиццаға, сушиден сеттер мен тіскебасарларға дейін таңдауға болады.',reviewsTitle:'Біз туралы пікірлер',r1:'Өте дәмді әрі атмосферасы керемет. Міндетті түрде қайта келемін!',r2:'Мәзірі үлкен, бәрі тәбетті көрінеді. Таңдауы ұнады.',r3:'Қызмет көрсетуі мен тағамдарының дәмі ұнады. Жақсы әсер қалдырды.',r4:'Отырып, дәмді тағам таңдауға жақсы орын.',contactsTitle:'Байланыс',phoneLabel:'Мекеме телефоны',call:'Қоңырау шалу',gis:'Біз 2GIS-те',supportEyebrow:'Техникалық қолдау',supportTitle:'Техникалық қолдау',supportNote:'Сайттың жұмысына қатысты сұрақтар бойынша',supportCall:'Техникалық қолдауға хабарласу',footerText:'Ресми сайт-визитка'}
};

const modal=document.getElementById('languageModal');
const nav=document.getElementById('nav');
const burger=document.getElementById('burger');

function setLang(lang){
  if(!translations[lang]) lang='ru';
  document.documentElement.lang=lang==='kz'?'kk':'ru';
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key=el.dataset.i18n;
    if(translations[lang][key]!==undefined) el.textContent=translations[lang][key];
  });
  document.querySelectorAll('.lang').forEach(btn=>btn.classList.toggle('active',btn.dataset.lang===lang));
  localStorage.setItem('mgo-lang',lang);
}

function closeModal(){modal.classList.add('hidden');document.body.classList.remove('modal-open')}
function openModal(){modal.classList.remove('hidden');document.body.classList.add('modal-open')}

document.querySelectorAll('.lang').forEach(btn=>btn.addEventListener('click',()=>setLang(btn.dataset.lang)));
document.querySelectorAll('[data-first-lang]').forEach(btn=>btn.addEventListener('click',()=>{setLang(btn.dataset.firstLang);localStorage.setItem('mgo-language-selected','1');closeModal()}));

burger.addEventListener('click',()=>{const open=nav.classList.toggle('open');burger.setAttribute('aria-expanded',String(open))});
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');burger.setAttribute('aria-expanded','false')}));

document.getElementById('menuButton').addEventListener('click',()=>document.getElementById('menu').scrollIntoView({behavior:'smooth'}));
document.getElementById('year').textContent=new Date().getFullYear();

const savedLang=localStorage.getItem('mgo-lang')||'ru';
setLang(savedLang);
if(localStorage.getItem('mgo-language-selected')==='1') closeModal(); else openModal();

function hideLoader(){const loader=document.getElementById('loader');if(loader)loader.classList.add('hidden')}
window.addEventListener('load',hideLoader);
setTimeout(hideLoader,1400);
