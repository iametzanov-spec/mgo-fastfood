MGO — готовый статический сайт

Файлы:
- index.html
- style.css
- script.js
- menu/menu-01.jpeg ... menu/menu-08.jpeg

ВАЖНО:
1. Не переименовывайте папку menu и изображения внутри неё.
2. Все 8 страниц меню используются как оригинальные изображения без изменения.
3. Откройте index.html двойным кликом — сайт работает без сервера.
4. Для GitHub Pages загрузите index.html, style.css, script.js и папку menu целиком в один репозиторий.
5. Фотография Hero подключена по предоставленной ссылке i.ibb.co.

Контакты MGO:
+7 747 244 9090
2GIS: https://2gis.kz/almaty/geo/70000001065723823

Техническая поддержка:
+7 700 322 0810
Instagram: https://www.instagram.com/ametzh.developer/
